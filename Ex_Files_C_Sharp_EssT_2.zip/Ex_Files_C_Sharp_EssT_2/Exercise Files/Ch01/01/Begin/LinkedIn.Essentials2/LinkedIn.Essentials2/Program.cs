﻿// See https://aka.ms/new-console-template for more information
using Essentials2.Library;


static void Swap(object first, object second)
{
    object temp = second;
    second = first;
    first = temp;
}