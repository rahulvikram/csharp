﻿using Essentials2.Library;

//CollectionSamples.Indexing();

//CollectionSamples.Iterating();

//CollectionSamples.Dictionary();

CollectionSamples.NameValue();